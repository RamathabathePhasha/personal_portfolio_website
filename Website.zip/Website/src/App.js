import React from 'react';
import Home from './components/Home';
import About from './components/About';
import Skills from './components/Skills';
import ProjectShowcase from './components/ProjectShowcase';
import './App.css';
import Reviews from './components/Reviews';
import ContactForm from './components/ContactForm';

function App() {
  return (
    <div> 
        <Home/>
        <About/>
        <Skills/>
        <ProjectShowcase/>
        <Reviews/>
        <ContactForm/>
      
    </div>
  )
}

export default App;

