import React from 'react';
import './ProjectShowcase.css';

const ProjectShowcase = () => {
  return (
    <div className="container">
      <h1>ProjectShowcase </h1>
      <div className="project">
        <h2>Project 1: Instagram wireframe</h2>
        <p>
          I've created a wireframe for an Instagram-like platform using Figma. It includes a clean and modern design, with features such as a homepage feed displaying posts from followed users, a profile page with user information and posts, a search feature to discover new users and content, and a posting interface to upload photos and videos. The wireframe focuses on user experience, with intuitive navigation and interaction elements.
        </p>
        <button type="+ See More">See More</button>
      </div>

      <div className="project">
        <h2>Project 2: Survey Form</h2>
        <p>
          I've built a survey form using HTML, CSS, and JavaScript. Upon submission, JavaScript captures user input and displays the information. Additionally, the h1 content dynamically changes to "Thank you for your submission!" to acknowledge the user's input.
        </p>
        <button type="+ See More">See More</button>
      </div>

      <div className="project">
        <h2>Project 3: Leap year</h2>
        <p>
          This 'Leap Year Checker' project is a Python application that determines whether a given year is a leap year or not. A leap year is a year that contains an additional day, February 29th, making it 366 days long instead of the usual 365 days.
        </p>
        <button type="+ See More">See More</button>
      </div>
    </div>
  );
};

export default ProjectShowcase;
