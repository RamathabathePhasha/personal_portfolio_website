import React from 'react';
import './Reviews.css';

const Reviews = () => {
   
  return (
    <div className="testimonials-container">
         <div className="row1">
    <h1>Reviews</h1>
    </div>
    <div className='row'>
      <div className=" column column1">
        <p>"Outstanding work! I've been really impressed by Windy's skills. She excels in team collaboration, always available and proactive in communication. Her work is consistently of high quality and delivered on time, ensuring everyone is updated on progress and deadlines without reminders. Windy's dedication and hard work significantly contributed to the success of our projects, resulting in excellent grades/marks. I highly recommend her and would definitely work with her again in the future."</p>
        <p>Details: Tumisang Thabathe</p>
        <p>Student: Belgium campus ITversity</p>
      </div>
      <div className=" column column2">
        <p>"Big shoutout to Windy Phasha for her incredible work on her Figma school project! She really nailed it, paying close attention to every detail and ensuring that the website design (User Interface) met all of the required specifications. She also managed to finish the project right on schedule. I would highly recommend her for similar designs."</p>
        <p>Details: Onalenna Mabilane</p>
        <p>Student: Belgium campus ITversity</p>
      </div>
    </div>
    </div>
  );
};

export default Reviews;
