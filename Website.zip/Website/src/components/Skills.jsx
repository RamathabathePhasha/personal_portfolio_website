import React from 'react';
import './Skills.css';

const Skills = () => {
  return (
    <div className='container'>
      <div className="row1">
        <h1>Skills</h1>
      </div>
      <div id="skills" className="skill-row">
        <div>
        <img src="criticalThinkingImage.jpg" alt="criticalThinkingImage"  width="40" height="40"/>
          <p>Critical Thinking</p>
        </div>
        <div>
        <img src="communicationImage.jpg" alt="communicationImage"  width="40" height="40"/>
          <p>Effective Communication</p>
        </div>
        <div>
        <img src="web developmentImage.jpg" alt="web developmentImage"  width="40" height="40"/>
          <p>Web development</p>
        </div>
        <div>
        <img src="python.jpg" alt="python"  width="40" height="40"/>
          <p>Python</p>
        </div>
        <div>
        <img src="figma.jpg" alt="figma"  width="40" height="40"/>
          <p>Figma</p>
        </div>
      </div>

      {/* Second row */}
      <div className="skill-row">
      <div>
        <img src="SQL.jpg" alt="Sql"  width="40" height="40"/>
          <p>Microsoft SQL</p>
        </div>
        <div>
        <img src="javaImage.png" alt="javaImage"  width="40" height="40"/>
          <p>Java</p>
        </div>
        <div>
        <img src="cSharpImage.jpg" alt="cSharpImage"  width="40" height="40"/>
          <p>C#</p>
        </div>
        <div>
        <img src="phpImage.jpg" alt="phpImage"  width="40" height="40"/>
          <p>PHP</p>
        </div>
      </div>
    </div>
  );
};

export default Skills;
