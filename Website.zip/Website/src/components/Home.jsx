import React from 'react';
import './Home.css'; 

function Home() {
  return (
    <div className="container">
      <nav>
        <div className="logo">PW</div>
        <div className="links">
          <a href="#home">Home</a>
          <a href="#about">About Me</a>
          <a href="#skills">Skills</a>
          <a href="#projects">Project Showcase</a>
          <a href="#reviews">Reviews</a>
          <a href="#contact">Contact Me</a>
        </div>
      <button><a href="/Phasha R.W Resume.pdf" download="Phasha R.W Resume.pdf">Download CV</a></button>
      </nav>
      <div className="row">
        <div id="home" className="column column1">
          <h1>Hi, I'm Windy</h1>
          <p>Welcome to my website!</p>
          <p>
            I'm a full stack developer with a focus on creating exceptional digital experiences using React.js and Node.js. Even though I haven't had formal work experience, I've been crafting web applications for a while now, and I still love it as if it was something new. My skills span various areas including JavaScript, HTML, CSS, information gathering, Python, Java, database implementation (SQL), database concepts and reporting, Power-BI/visualization, C#, PHP, teamwork/collaboration, end-user computing, and UI/UX design. I'm confident in my ability to tackle any challenges or opportunities that may arise.
          </p>
          <div><p>
            Check out my skills and projects on:</p></div>
          <div>
           <div> <a href="https://github.com/RamathabathePhasha" target="_blank" rel="noopener noreferrer">
              GitHub
            </a></div>
           <div><a href="https://www.figma.com/files/user/1357031493858049271?fuid=1357031493858049271" target="_blank" rel="noopener noreferrer">
              Figma
            </a></div>
            <div><a
              href="https://www.linkedin.com/in/ramathabathe-phasha-93b5a3246/?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app"
              target="_blank"
              rel="noopener noreferrer"
            >
              LinkedIn
            </a></div>
            <div>
            <p>You can also reach me at:</p>
            <a href="phashawindy@gmail.com">
              phashawindy@gmail.com
            </a></div>
            <div>
              Phone : 079 709 4270
            </div>
          </div>
        </div>
        <div className="column column2">
          <img src="WindyImage.jpg" alt="WindyImage"  height="550"/>
        </div>
      </div>
    </div>

  );
}

export default Home;
