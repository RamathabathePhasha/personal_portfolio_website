import React from 'react';
import './About.css';

function About() {
  return (
    <div className='container'>
      <div className="row1">
        <h1>About Me</h1>
      </div>
      <div className='row'>
        <div id="about" className='column column1'>
          <img src="WindyImage.jpg" alt="WindyImage"  width="450" height="964"/>
        </div>
        <div className='column column2'> 
          <div className='about-text'>
            <h3>Curious about me? Here you have it:</h3>
            <p>
              I'm a determined young woman who loves IT, currently in my third year of studying IT 
              software development. Even though I haven't worked yet, I've completed numerous projects
              and assignments that showcase my skills. I hold National Certificates in IT System
              Development from Jeppe College, earned in 2020 and 2021, demonstrating my commitment
              to learning and proficiency in IT. Additionally, I'm currently pursuing a Diploma 
              in Software Development at Belgium Campus ITversity, having completed all the modules
              for my first and second years, which have further enhanced my software development skills.
            </p>

            <p>
              In terms of my ideal job, I'm passionate about web development or data analysis.
              I'm excited about using tools like HTML, CSS, and JavaScript for front-end development,
              and languages like Python or Java for back-end development. I'm interested in industries 
              such as technology, e-commerce, or finance, where I can apply my skills to create
              user-friendly websites or analyze data for insights and decisions.
            </p>

            <p>
              Regarding my expertise, I bring proficiency in several areas including JavaScript, 
              HTML, CSS, information gathering, Python, Java, database implementation (SQL), 
              database concepts and reporting, Power-Bi/visualization, C#, PHP, teamwork/collaboration,
              end-user computing, and React.
            </p>

           <p> <ul>
              <li>National Certificates in IT System development NQF 4 and 5</li>
              <li>Diploma in Software Development at Belgium Campus ITversity NQF 6 (Present)</li>
              <li>Effective Communication</li>
              <li>Critical Thinking</li>
            </ul></p>


            <p>
              One last thing, I'm currently seeking opportunities for a 6-month internship 
              as part of my course curriculum. I'm eager to apply my skills and knowledge 
              in a real-world setting, and I promise I'm friendly and enthusiastic about learning.
              Feel free to reach out and say hello! I'm open to discussing potential internship
              opportunities and how I can contribute to your team.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default About;
